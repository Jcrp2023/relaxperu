import React, { useState, useMemo } from "react";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";

const eventosMock = [
  { id: 1, titulo: "Concierto Sinfónico en Lima", categoria: "Conciertos", subcategoria: "Cultural", edad: "18+", fecha: "2025-06-10", hora: "20:00", ninosPermitidos: false, enlace: "https://www.teleticket.com.pe" },
  { id: 2, titulo: "Feria Gastronómica en Arequipa", categoria: "Ferias", subcategoria: "Culinaria", edad: "Para todos", fecha: "2025-06-12", hora: "11:00", ninosPermitidos: true, enlace: "https://www.joinnus.com" },
  { id: 3, titulo: "Tour Arquitectónico por el Centro Histórico de Lima", categoria: "Turismo", subcategoria: "Arquitectura", edad: "Para todos", fecha: "2025-06-15", hora: "10:00", ninosPermitidos: true, enlace: "https://www.turismolima.pe" },
  { id: 4, titulo: "Ruta Gastronómica Miraflores para Jóvenes", categoria: "Turismo", subcategoria: "Gastronomía", edad: "18-30", fecha: "2025-06-20", hora: "17:00", ninosPermitidos: false, enlace: "https://www.joinnus.com" },
  { id: 5, titulo: "Viaje Grupal a Paracas con Experiencia Marina", categoria: "Viajes grupales", subcategoria: "Naturaleza", edad: "Para todos", fecha: "2025-06-22", hora: "06:00", ninosPermitidos: true, enlace: "https://www.experienciaperu.travel" },
  { id: 6, titulo: "Clase de Cocina Peruana para Turistas", categoria: "Turismo", subcategoria: "Culinaria", edad: "Para todos", fecha: "2025-06-25", hora: "14:00", ninosPermitidos: true, enlace: "https://www.cookingexperiences.pe" },
  { id: 7, titulo: "Tour Histórico y Cultural en Cusco", categoria: "Turismo", subcategoria: "Historia", edad: "Para todos", fecha: "2025-06-28", hora: "09:00", ninosPermitidos: true, enlace: "https://www.cuscotours.pe" }
];

function FiltroEventos({ busqueda, soloConNinos }) {
  const eventosFiltrados = useMemo(() => {
    return eventosMock.filter(evento => {
      const coincideTexto = evento.titulo.toLowerCase().includes(busqueda.toLowerCase()) || evento.categoria.toLowerCase().includes(busqueda.toLowerCase()) || evento.subcategoria.toLowerCase().includes(busqueda.toLowerCase());
      const coincideNinos = !soloConNinos || evento.ninosPermitidos;
      return coincideTexto && coincideNinos;
    });
  }, [busqueda, soloConNinos]);

  if (eventosFiltrados.length === 0) {
    return <p>No se encontraron eventos.</p>;
  }

  return eventosFiltrados.map((evento) => (
    <Card key={evento.id}>
      <CardContent className="p-4">
        <h2 className="text-xl font-semibold">{evento.titulo}</h2>
        <p className="text-sm text-gray-600">Categoría: {evento.categoria} - {evento.subcategoria}</p>
        <p className="text-sm">Fecha: {evento.fecha} a las {evento.hora}</p>
        <p className="text-sm">{evento.ninosPermitidos ? "Niños permitidos" : "Solo adultos"}</p>
        <a href={evento.enlace} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline text-sm">Más información</a>
      </CardContent>
    </Card>
  ));
}

export default function EventosApp() {
  const [busqueda, setBusqueda] = useState("");
  const [soloConNinos, setSoloConNinos] = useState(false);

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Descubre experiencias y eventos en Perú</h1>
      <Input
        placeholder="Buscar por título, categoría o tipo de experiencia (ej. gastronomía, arquitectura, historia)"
        value={busqueda}
        onChange={(e) => setBusqueda(e.target.value)}
        className="mb-4"
      />
      <label className="mb-4 block">
        <input
          type="checkbox"
          checked={soloConNinos}
          onChange={() => setSoloConNinos(!soloConNinos)}
          className="mr-2"
        />
        Mostrar solo eventos donde se permiten niños
      </label>
      <div className="grid gap-4">
        <FiltroEventos busqueda={busqueda} soloConNinos={soloConNinos} />
      </div>
      <footer className="mt-10 text-center text-xs text-gray-500 border-t pt-4">
        © 2025 RelaxPerú. Esta plataforma es un buscador de eventos y experiencias. No gestionamos entradas ni organizamos eventos. Verifica siempre el origen de las páginas externas.
      </footer>
    </div>
  );
}
