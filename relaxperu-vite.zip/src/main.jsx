import React from 'react'
import ReactDOM from 'react-dom/client'
import EventosApp from './EventosApp'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <EventosApp />
  </React.StrictMode>
)
